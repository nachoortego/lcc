-module(broadcast).

-export([iniciar/0, finalizar/0]).
-export([broadcast/1, registrar/0]).
-export([loopBroadcast/1, client/0, test/0, ack/0]).

ack () ->
    receive
        servOk -> ok;
        servErr -> err
    end.
    
%%% Iniciar el servidor y registrar el proceso
iniciar() ->
    Pid = spawn(?MODULE, loopBroadcast, [[]]),  % spawn(Module, Function, Args)
    register(server, Pid).


%%% Enviar señal de finalización al servidor
finalizar() ->
    server ! fin,
    ack().

%%% Registrar un cliente (el proceso actual)
registrar() ->
    server ! {register, self()},
    ack().

%%% Enviar mensaje a todos los clientes registrados
broadcast(Msg) ->
    server ! {send, Msg},
    ack().

%%% Loop principal del servidor de broadcast
loopBroadcast(ListaClientes) ->
    receive
        {register, PidCliente} ->
            PidCliente ! servOk,
            io:format("Registrado cliente: ~p~n", [PidCliente]),
            loopBroadcast([PidCliente | ListaClientes]);
        {send, Msg, PidCliente} ->
            PidCliente ! servOk,
            lists:foreach(fun(Pid) -> Pid ! Msg end, ListaClientes),
            loopBroadcast(ListaClientes);
        {fin, PidCliente} ->
            io:format("Servidor finalizado~n"),
            PidCliente ! {servOk},
            ok
    end.

%%% Cliente: se registra y espera recibir un mensaje
client() ->
    registrar(),
    receive
        Msg ->
            io:format("Cliente ~p recibió mensaje: ~p~n", [self(), Msg])
    end.

%%% Prueba del servicio
test() ->
    iniciar(),
    spawn(?MODULE, client, []),
    spawn(?MODULE, client, []),
    timer:sleep(1000),
    broadcast("¡Hola a todos!").

