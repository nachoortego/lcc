#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>

/*
 * Para probar, usar netcat. Ej:
 *
 *      $ nc localhost 4040
 *      NUEVO
 *      0
 *      NUEVO
 *      1
 *      CHAU
 */

void quit(char *s)
{
  perror(s);
  abort();
}

int *U; // Puntero a la memoria compartida para la cuenta de U

int fd_readline(int fd, char *buf)
{
  int rc;
  int i = 0;

  /*
   * Leemos de a un caracter (no muy eficiente...) hasta
   * completar una línea.
   */
  while ((rc = read(fd, buf + i, 1)) > 0) {
    if (buf[i] == '\n')
      break;
    i++;
  }

  if (rc < 0)
    return rc;

  buf[i] = 0;
  return i;
}

void handle_conn(int csock)
{
  char buf[200];
  int rc;

  while (1) {
    /* Atendemos pedidos, uno por linea */
    rc = fd_readline(csock, buf);
    if (rc < 0)
      quit("read... raro");

    if (rc == 0) {
      /* linea vacia, se cerró la conexión */
      close(csock);
      return;
    }

    if (!strcmp(buf, "NUEVO")) {
      char reply[20];

      // Incrementamos U en memoria compartida
      sprintf(reply, "%d\n", *U);
      (*U)++;
      write(csock, reply, strlen(reply));
    } else if (!strcmp(buf, "CHAU")) {
      close(csock);
      return;
    }
  }
}

void wait_for_clients(int lsock)
{
  int csock;
  pid_t pid;

  while (1) {
    /* Esperamos una conexión */
    csock = accept(lsock, NULL, NULL);
    if (csock < 0)
      quit("accept");

    /* Creamos un nuevo proceso para manejar la conexión */
    pid = fork();
    if (pid < 0) {
      quit("fork");
    }

    if (pid == 0) {
      /* En el proceso hijo, manejamos la conexión */
      handle_conn(csock);
      close(csock);  // Cerramos el socket en el hijo
      exit(0);       // Terminamos el proceso hijo
    } else {
      /* En el proceso padre, cerramos el socket */
      close(csock);
    }
  }
}

// accept() sigue bloqueando esperando una nueva conexión.
// Si fork() tiene éxito, el proceso padre (pid > 0) cierra el socket de cliente, ya que no lo necesita más.
// El proceso hijo (pid == 0) maneja la conexión con el cliente y luego termina.
// Al usar exit(0) en el proceso hijo, nos aseguramos de que el proceso hijo termine correctamente una vez que haya atendido al cliente.


/* Crea un socket de escucha en puerto 4040 TCP */
int mk_lsock()
{
  struct sockaddr_in sa;
  int lsock;
  int rc;
  int yes = 1;

  /* Crear socket */
  lsock = socket(AF_INET, SOCK_STREAM, 0);
  if (lsock < 0)
    quit("socket");

  /* Setear opción reuseaddr... normalmente no es necesario */
  if (setsockopt(lsock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes) == 1)
    quit("setsockopt");

  sa.sin_family = AF_INET;
  sa.sin_port = htons(4040);
  sa.sin_addr.s_addr = htonl(INADDR_ANY);

  /* Bindear al puerto 4040 TCP, en todas las direcciones disponibles */
  rc = bind(lsock, (struct sockaddr *)&sa, sizeof sa);
  if (rc < 0)
    quit("bind");

  /* Setear en modo escucha */
  rc = listen(lsock, 10);
  if (rc < 0)
    quit("listen");

  return lsock;
}

int main()
{
  int lsock;

  /* Crear memoria compartida */
  int shm_fd = shm_open("/shared_U", O_CREAT | O_RDWR, 0666);
  if (shm_fd == -1)
    quit("shm_open");

  /* Configurar el tamaño de la memoria compartida */
  if (ftruncate(shm_fd, sizeof(int)) == -1)
    quit("ftruncate");

  /* Mapear la memoria compartida */
  U = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
  if (U == MAP_FAILED)
    quit("mmap");

  /* Inicializar U en memoria compartida */
  *U = 0;

  lsock = mk_lsock();
  wait_for_clients(lsock);

  /* Desvincular y cerrar la memoria compartida */
  shm_unlink("/shared_U");
  return 0;
}