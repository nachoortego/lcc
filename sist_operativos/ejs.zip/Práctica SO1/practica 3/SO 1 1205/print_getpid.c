#include<stdio.h>
#include<unistd.h>

int main(){
    printf("pid: %d",getpid());
    return 0;
}