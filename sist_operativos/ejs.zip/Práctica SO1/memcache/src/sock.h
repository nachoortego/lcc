#ifndef __SOCK_H
#define __SOCK_H 1

#include <netinet/in.h>

int mk_tcp_sock(in_port_t port);

#endif
