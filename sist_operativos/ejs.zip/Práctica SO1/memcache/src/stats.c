#include "stats.h"

struct stats *_STATS;
